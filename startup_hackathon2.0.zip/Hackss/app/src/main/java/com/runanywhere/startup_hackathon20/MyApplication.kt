package com.runanywhere.startup_hackathon20

import android.app.Application
import android.util.Log

class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.i("PAWSYNC", "App started successfully")

        // Initialize SDK asynchronously later to prevent startup delays
        // For now, let's get the app running first
    }
}
